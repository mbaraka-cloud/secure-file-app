from app.extensions import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
import time
from datetime import datetime

class User(db.Model, UserMixin):
    __tablename__ = "user"  # important pour correspondre aux FKs existants

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)

    role = db.Column(db.String(20), nullable=False, default='user')  # 'user' | 'admin'
    credits = db.Column(db.Integer, nullable=False, default=0)

    # Authentification 2FA
    two_factor_enabled = db.Column(db.Boolean, default=False)
    two_factor_secret = db.Column(db.String(64), nullable=True)  # 32..64 selon lib ; on garde large

    # Protection brute force
    failed_attempts = db.Column(db.Integer, default=0)
    banned_until = db.Column(db.Integer, default=0)  # Timestamp UNIX (secondes)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ⛔️ AUCUNE relationship déclarée ici (pour éviter le conflit de backref 'owner')
    # Si tu as besoin d'accéder aux fichiers d'un user :
    # utilise la relationship déjà définie côté EncryptedFile (ex: f.owner)
    # ou une requête filtrée EncryptedFile.user_id == user.id

    # --- Helpers ---
    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def is_admin(self) -> bool:
        return self.role == 'admin'

    def is_banned(self) -> bool:
        return time.time() < (self.banned_until or 0)

    def __repr__(self):
        return f"<User {self.username} ({self.role})>"
